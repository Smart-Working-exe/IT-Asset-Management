create definer = swe_praktikum@`%` view view_geraet_hat_betriebssystem as
select `gb`.`geraetid`                                                                AS `geraetid`,
       concat_ws('', trim(concat_ws(' ', `b`.`name`, ifnull(`b`.`version`, ''))), '') AS `name`
from (`swe`.`geraet_hat_betriebssystem` `gb` left join `swe`.`betriebssystem` `b`
      on (`gb`.`betriebssystemid` = `b`.`id`));

-- comment on column view_geraet_hat_betriebssystem.geraetid not supported: Referenz auf Geräte

