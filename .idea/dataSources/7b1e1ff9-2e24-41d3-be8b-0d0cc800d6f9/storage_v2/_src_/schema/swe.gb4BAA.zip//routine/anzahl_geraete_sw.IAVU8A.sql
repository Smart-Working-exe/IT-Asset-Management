create
    definer = swe_praktikum@`%` procedure anzahl_geraete_sw(IN id int, OUT anzahl int)
BEGIN
    SELECT Count(*) into anzahl from geraet_hat_software where softwarelizenzid = id;
END;

