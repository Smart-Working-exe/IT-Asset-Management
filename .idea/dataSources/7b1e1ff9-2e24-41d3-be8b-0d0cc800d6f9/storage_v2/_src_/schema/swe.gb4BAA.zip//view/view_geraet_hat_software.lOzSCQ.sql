create definer = swe_praktikum@`%` view view_geraet_hat_software as
select `gs`.`geraetid`                                                                AS `geraetid`,
       concat_ws('', trim(concat_ws(' ', `s`.`name`, ifnull(`s`.`version`, ''))), '') AS `name`
from (`swe`.`geraet_hat_software` `gs` left join `swe`.`softwarelizenzen` `s` on (`gs`.`softwarelizenzid` = `s`.`id`));

-- comment on column view_geraet_hat_software.geraetid not supported: Referenz auf Geräte

